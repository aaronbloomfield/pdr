#include <iostream>
using namespace std;
#include "tomatosauce.h"

TomatoSauce::TomatoSauce(int amount) {
    quantity=amount;
}
