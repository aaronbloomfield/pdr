#ifndef PIZZADOUGH_H
#define PIZZADOUGH_H
class PizzaDough {
private:
    int quantity;
public:
    PizzaDough(int amount);
};
#endif
