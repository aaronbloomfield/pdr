#ifndef TOMATOSAUCE_H
#define TOMATOSAUCE_H
class TomatoSauce {
private:
    int quantity;
public:
    TomatoSauce(int amount);
};
#endif
