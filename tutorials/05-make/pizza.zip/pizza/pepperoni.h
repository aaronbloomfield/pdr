#ifndef PEPPERONI_H
#define PEPPERONI_H
class Pepperoni {
private:
    int quantity;
public:
    Pepperoni();
    Pepperoni(int amount);
};
#endif
