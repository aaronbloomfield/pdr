#ifndef CHEESE_H
#define CHEESE_H
class Cheese {
private:
    int quantity;
public:
    Cheese();
    Cheese(int amount);
};
#endif
