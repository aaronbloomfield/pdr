#include "peppers.h"

Peppers::Peppers() {
    quantity=0;
}

Peppers::Peppers(int amount) {
    quantity=amount;
}
